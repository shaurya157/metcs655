# CS665 Project

This is final project for CS665.  The following readme can be used as user guide
to install and run the application using Java.  


# Program Assumptions

This is a simple console emulator application of a controller which controls multiple devices.   
In the era of connected devices, it is handy to have application which controls multiple devices from a single place.

In this emulator I have considered 3 home appliance devices : TV, AC, Radio.  

The application is built to connect one device at a time, user will act on the selected device. Once the user is done with operation of the device, user can disconnect and connect to another device. The device status will be retained unless it is switched off. 

It is a console emulator, listening to user inputs as numbers.  
Application itself gives proper documents and device status for every request and gives list of next possible requests. 


# Implementation Description

In this example I have used design patterns as listed. 

> Creational Design Pattern 	: **Builder**, **Singleton**, **Dependency Injection**.  
> Structural Design Pattern 	: **Front Controller**.  
> Behavioral Design Pattern 	: **Strategy**, **Caching**.   

The application is designed with two parts. User action and Business Logic.   
Business logic section just updates device data in a application Cache. In the real world it is responsible to connect to the physical device API's. 
And user action is separated out so that in the future we can implement rest interfaces to the application. 

User action part is implemented with **Front Controller Design Pattern** where all the requests/inputs from the user is received by a Dispatcher. Which handles the request and decides which part of the application the request need to be dispatched. Where controller comes into picture. Separate controllers are implemented for each device with **Strategy Design Pattern**.   And the dispatcher will select the controller and send the user request for further processing. 

A Device Cache is maintained. Where the state of each device will be kept, which uses the concepts of **Caching Design Pattern**. And with the **Singleton Design Pattern**,  only one device of each type will be instantiated and kept in the cache during application startup, these device objects will be retaining in the cache till application shutdown.  


Each ``AirConditioner``, ``Television``, ``RadioDevice`` implements the Device interface. Making a different strategy of their own. All applicable functionalities, ``SwitchOn``, ``Switch Off``, ``Play``, ``Stop``, etc. are represented by different interfaces like ``Switchable``, ``Playable``, ``VolumeEnabled`` etc.. 

Dispatcher can be injected using **Dependency Injection** pattern for a View object. View object is  also follows Singleton rule and through out the application cycle only one Object of View class will be exist. This View object is responsible to read  from and write the data to console. 

**Builder Design pattern** is used for creating various View specific objects like ``ViewRequest``, ``ViewData``.

The application can be easily enhanced with the REST Api's and HTML views. Also application can connect to as many as devices using their interfaces. 

Enough Documentation and JUnit Tests are provided in the code.   
UML class diagram representing the major classes of implementation is in project-front-controller-uml.pdf

# Project Template

We use Apache Maven and JDK1.8 to compile and run this project. 

Please make sure that `java` and `mvn` commands are added to system path. 


# How to compile the project

```bash
mvn clean compile
```

# How to create a binary runnable package 


```bash
mvn clean compile assembly:single
```


# How to run


```bash
mvn clean compile assembly:single

java -jar target/assignment-project-1.0-SNAPSHOT-jar-with-dependencies.jar

OR

./run.sh
```


# Run all the unit test classes.


```bash
mvn clean compile test

```

# Using Findbugs 

To see bug detail using the Findbugs GUI, use the following command "mvn findbugs:gui"

Or you can create a XML report by using  


```bash
mvn findbugs:gui 
```

or 


```bash
mvn findbugs:findbugs
```


For more info about FindBugs see 

http://findbugs.sourceforge.net/

And about Maven Findbug plugin see 
https://gleclaire.github.io/findbugs-maven-plugin/index.html


You can install Findbugs Eclipse Plugin 

http://findbugs.sourceforge.net/manual/eclipse.html



SpotBugs https://spotbugs.github.io/ is the spiritual successor of FindBugs.


# Run Checkstyle 

CheckStyle code styling configuration files are in config/ directory. Maven checkstyle plugin is set to use google code style. 
You can change it to other styles like sun checkstyle. 

To analyze this example using CheckStyle run 

```bash
mvn checkstyle:check
```

This will generate a report in XML format


```bash
target/checkstyle-checker.xml
target/checkstyle-result.xml
```

and the following command will generate a report in HTML format that you can open it using a Web browser. 

```bash
mvn checkstyle:checkstyle
```

```bash
target/site/checkstyle.html
```


# Generate  coveralls:report 

You can find more info about coveralls 

https://coveralls.io/

```bash
mvn -DrepoToken=YOUR-REPO-TOCKEN-ON-COVERALLS  cobertura:cobertura coveralls:report
```

