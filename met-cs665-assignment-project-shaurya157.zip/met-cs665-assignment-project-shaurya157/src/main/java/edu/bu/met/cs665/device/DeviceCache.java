package edu.bu.met.cs665.device;

import java.util.HashMap;
import java.util.Map;

import edu.bu.met.cs665.device.Device.DeviceType;

/**
 * Device Cache, responsible for holding the singleton device objects throughout application life cycle.
 *
 */
public class DeviceCache {

	private DeviceCache() {
		
	}
	private static final Map<DeviceType, Device> devices = new HashMap<>();
	
	static {
		devices.put(DeviceType.AC, new AirConditioner());
		devices.put(DeviceType.TV, new TeleVision());
		devices.put(DeviceType.RADIO, new RadioDevice());
	}
	
	public static Device getDevice(DeviceType type) {
		return devices.get(type);
	}
}
