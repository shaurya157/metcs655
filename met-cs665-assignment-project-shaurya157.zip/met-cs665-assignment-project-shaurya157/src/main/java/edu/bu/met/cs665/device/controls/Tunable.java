package edu.bu.met.cs665.device.controls;

public interface Tunable {
	
	// current freq
	double getFrequency();

	// rotate right
	void rotateRight(double value);
	
	//rotate left
	void rotateLeft(double value);
}
