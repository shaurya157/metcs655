package edu.bu.met.cs665.controller;

import edu.bu.met.cs665.device.Device;
import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * Controller responsible to connect to device. 
 */
public class HomeController extends AbstractDeviceController {

	@Override
	protected void loadMethodMap() {
		methodMap.put(ViewAction.SELECT_TV, "onSelectTv");
		methodMap.put(ViewAction.SELECT_AC, "onSelectAc");
		methodMap.put(ViewAction.SELECT_RADIO, "onSelectRadio");
	}
		
	public HomeController() {
		init();
	}
	
	public  void onSelectTv(ViewRequest request, ViewResponse response) {
		Device device = DeviceCache.getDevice(DeviceType.TV);
		response.setType(DeviceType.TV);
		response.addInfo("TV Connected Successfully", true);
		setDeviceStatus(response, device);
	}
	
	public void onSelectAc(ViewRequest request, ViewResponse response) {
		Device device = DeviceCache.getDevice(DeviceType.AC);
		response.setType(DeviceType.AC);
		response.addInfo("AC Connected Successfully", true);
		setDeviceStatus(response, device);
	}
	
	public void onSelectRadio(ViewRequest request, ViewResponse response) {
		Device device = DeviceCache.getDevice(DeviceType.RADIO);
		response.setType(DeviceType.RADIO);
		response.addInfo("Radio Connected Successfully", true);
		setDeviceStatus(response, device);
	}
	
}
