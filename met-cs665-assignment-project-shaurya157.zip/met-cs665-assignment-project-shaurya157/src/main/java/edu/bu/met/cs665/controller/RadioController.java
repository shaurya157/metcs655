package edu.bu.met.cs665.controller;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.device.RadioDevice;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * 
 * Responsible for controlling radio device.
 */
public class RadioController extends TvController {
	public RadioController() {
		super();
		super.device = DeviceType.RADIO;
	}
	
	@Override
	protected void loadMethodMap() {
		super.loadMethodMap();
		methodMap.put(ViewAction.FREQUENCEY_DOWN, "onFrequnecyDown");
		methodMap.put(ViewAction.FREQUENCEY_UP, "onFrequencyUp");
	}
	
	public void onFrequencyUp(ViewRequest request, ViewResponse response) {
		RadioDevice radio =  (RadioDevice) DeviceCache.getDevice(this.device);
		radio.rotateRight(1);
		response.addInfo("Frequency incremented by 1 unit", true);
		setDeviceStatus(response, radio);
	}
	
	public void onFrequnecyDown(ViewRequest request, ViewResponse response) {
		RadioDevice radio =  (RadioDevice) DeviceCache.getDevice(this.device);
		radio.rotateLeft(1);
		response.addInfo("Frequency decremented by 1 unit", true);
		response.setActions(radio.getAvailableActions());
		setDeviceStatus(response, radio);
	}
}
