package edu.bu.met.cs665.device.controls;

public interface TemparatureEnabled {
	//temperature value
	double getTemp();
	
	//temperature Increment
	void incrementTemp(double value);
	
	//temperature Decrement
	void decrementTemp(double value);
	
	void reset();
}
