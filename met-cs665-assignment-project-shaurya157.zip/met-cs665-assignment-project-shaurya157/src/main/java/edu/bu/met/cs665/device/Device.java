package edu.bu.met.cs665.device;

import java.util.List;

import edu.bu.met.cs665.device.controls.Switchable;
import edu.bu.met.cs665.view.ViewAction;

/**
 * 
 *
 */
public interface Device extends Switchable {
	
	/**
	 * API to get valid actions with respect to current device status.
	 * @return
	 */
	public List<ViewAction> getAvailableActions();
	
	/**
	 * String representation of the current device status. 
	 */
	public String getStatus();
	
	public  static enum DeviceType {
		CONNECTOR("Device Connector"), TV("TV"), AC("AC"),RADIO("Radio");
		
		private String code;
		
		private DeviceType(String code) {
			this.code = code;
		}
		
		public String toString() {
			return this.code;
		}
	}
}
