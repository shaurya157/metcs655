package edu.bu.met.cs665.view;

import java.util.ArrayList;
import java.util.List;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.ViewLog.LogLevel;

public class ViewResponse {

	private ViewData view;

	public ViewResponse(ViewData view) {
		this.view = view;
	}

	public ViewData getView() {
		return view;
	}

	public void setView(ViewData view) {
		this.view = view;
	}
	
	public void setActions(List<ViewAction> actions) {
		view.setActions(actions);
	}
	
	public void addAction(ViewAction action, boolean reset) {
		if(reset) {
			view.setActions(new ArrayList<ViewAction>());
		}
		view.getActions().add(action);
	}
	
	private void addLog(ViewLog log, boolean reset) {
		if(reset) {
			view.setLogs(new ArrayList<ViewLog>());
		}
		view.getLogs().add(log);
	}
	
	public void setType(DeviceType type) {
		view.setDeviceType(type);
	}
	
	public DeviceType getType() {
		return view.getDeviceType();
	}
	
	public void addInfo(String message, boolean reset) {
		addLog(new ViewLog(message, LogLevel.INFO), reset);
	}
	
	public void addError(String message, boolean reset) {
		addLog(new ViewLog(message, LogLevel.ERROR), reset);
	}
	
	public void show() {
		view.show();
	}
	
	public void initView() {
		this.setView(ViewData.initView(true));
	}
}
