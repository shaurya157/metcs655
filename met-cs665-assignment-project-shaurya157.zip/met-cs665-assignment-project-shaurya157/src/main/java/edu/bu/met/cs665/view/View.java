package edu.bu.met.cs665.view;

import java.util.Scanner;

import org.apache.log4j.Logger;

import edu.bu.met.cs665.application.ApplicationContext;
import edu.bu.met.cs665.dispatcher.IDispatcher;
import edu.bu.met.cs665.dispatcher.IODispatcher;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;

/**
 * View is responsible for read and write operations. 
 * The read operation will be responsible for collecting
 * data from user (request) and sending to a dispatcher. 
 * Once dispatcher is handled the request it will call write 
 * Operation with data to write into the console. 
 */
public class View {

	private static Logger log = Logger.getLogger(View.class);
	private static View view = new View(); // Singleton object
	private static Scanner scanner = new Scanner(System.in, "utf-8");;
	
	// Can be injected on demand
	private IDispatcher dispatcher = new IODispatcher(); 
	
	
	private View() {
		// private constructor for avoiding direct initialization
	}
	
	/**
	 * Method that can be used for dependency injection.
	 * @param dispatcher
	 */
	public void setDispatcher(IDispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}


	public static View getInstance() {
		return view;
	}
	
	public void write(String data) {
		log.info(data);
	}
	
	public void read() {
		while(scanner.hasNext()) {
			try {
				int request = scanner.nextInt();
				
				ViewResponse response = ApplicationContext.getResponse();
				handleRequest(request, response);
				
				response.show();
			} catch (Exception e) {
				log.error("Error while operating", e);
				break;
			}
		}

		exit();
		log.info("Exiting upon error");
		System.exit(0);
	}

	public void handleRequest(int request, ViewResponse response) {
		ViewRequest viewRequest;
		if(isValidRequest(request)) {
			log.debug("User entered option "+request);
			viewRequest = createRequest(request);
			dispatcher.handleRequest(viewRequest, response);
		} else {
			log.debug("Wrong option entered by user"+request);
			createErrorResponse(response);
		}
	}
	
	public void exit() {
		if(scanner != null) {
			scanner.close();
		}
	}
	
	private boolean isValidRequest(int request) {
		return request > 0 && ViewData.getInstance().getActions().size() >= request;
	}
	
	private ViewRequest createRequest(int request) {
		ViewAction viewAction = ViewData.getInstance().getActions().get(request-1);
		return new ViewRequestBuilder()
				.action(viewAction)
				.device(ApplicationContext.getViewData().getDeviceType())
				.build();
	}
	
	private void createErrorResponse(ViewResponse response) {
		 response.addError("Error ! Wrong command Entered.. \nPlease choose one of the following options", true);
	}
}
