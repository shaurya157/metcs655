package edu.bu.met.cs665.application;

import java.util.HashMap;
import java.util.Map;

import edu.bu.met.cs665.controller.AcController;
import edu.bu.met.cs665.controller.HomeController;
import edu.bu.met.cs665.controller.IController;
import edu.bu.met.cs665.controller.RadioController;
import edu.bu.met.cs665.controller.TvController;
import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.View;
import edu.bu.met.cs665.view.ViewData;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * A Application Context cache which holds current View data and All available Device Control objects. 
 * 
 */
public class ApplicationContext {

	private static Map<DeviceType, IController> requestMappings = new HashMap<DeviceType, IController>();
	private static ViewData data;
	
	static {
		requestMappings.put(DeviceType.CONNECTOR, new HomeController());
		requestMappings.put(DeviceType.AC, new AcController());
		requestMappings.put(DeviceType.TV, new TvController());
		requestMappings.put(DeviceType.RADIO, new RadioController());
		data = ViewData.initView(false);
	}
	
	/**
	 * Responsible for initializing the application.
	 */
	public static void initContext() {
		data.show();
		View.getInstance().read();
	}
	
	public static ViewData getViewData() {
		return data;
	}
	
	public static void setViewData(ViewData d) {
		data = d;
	}
	
	public static IController getController(DeviceType type) {
		return requestMappings.get(type);
	}
	
	public static ViewResponse getResponse() {
		return new ViewResponse(ApplicationContext.getViewData());
	}
}
