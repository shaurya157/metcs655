package edu.bu.met.cs665.device.controls;

public interface Playable  {
	
	//video status
	PlayStatus getPlayStatus();
		
	void pause();
	void play();
	void stopPlay();
	
	public static enum PlayStatus {
		IDLE,PAUSED,PLAYING
	}	
}
