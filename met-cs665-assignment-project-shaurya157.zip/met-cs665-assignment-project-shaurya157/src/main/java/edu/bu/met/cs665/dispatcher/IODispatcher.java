package edu.bu.met.cs665.dispatcher;

import edu.bu.met.cs665.application.ApplicationContext;
import edu.bu.met.cs665.controller.IController;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

public class IODispatcher implements IDispatcher {


	@Override
	public void handleRequest(ViewRequest request, ViewResponse response) {
		IController controller = ApplicationContext.getController(request.getDevice());
		controller.processRequest(request, response);
	}
}
