package edu.bu.met.cs665.controller;

import edu.bu.met.cs665.device.BasicMediaDevice;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * Responsible to control the TV actions.
 */
public class TvController extends AbstractDeviceController {
	
	protected DeviceType device = DeviceType.TV;

	public TvController() {
		super();
	}
	
	@Override
	protected void loadMethodMap() {
		methodMap.put(ViewAction.PLAY, "onPlay");
		methodMap.put(ViewAction.PAUSE, "onPause");
		methodMap.put(ViewAction.STOP, "onStop");
		methodMap.put(ViewAction.VOLUME_DOWN, "onVolumeDown");
		methodMap.put(ViewAction.VOLUME_UP, "onVolumeUp");

	}
	
	public void onPlay(ViewRequest request, ViewResponse response) {
		BasicMediaDevice basicMediaDevice = (BasicMediaDevice) DeviceCache.getDevice(this.device);
		basicMediaDevice.play();
		response.addInfo("Play Button clicked", true);
		setDeviceStatus(response, basicMediaDevice);
	}
	
	public void onPause(ViewRequest request, ViewResponse response) {
		BasicMediaDevice basicMediaDevice = (BasicMediaDevice) DeviceCache.getDevice(this.device);
		basicMediaDevice.pause();
		response.addInfo("Pause Button clicked", true);
		setDeviceStatus(response, basicMediaDevice);
	}
	
	public void onStop(ViewRequest request, ViewResponse response) {
		BasicMediaDevice basicMediaDevice = (BasicMediaDevice) DeviceCache.getDevice(this.device);
		basicMediaDevice.stopPlay();
		response.addInfo("Stop Button clicked", true);
		setDeviceStatus(response, basicMediaDevice);
	}
	
	public void onVolumeUp(ViewRequest request, ViewResponse response) {
		BasicMediaDevice basicMediaDevice = (BasicMediaDevice) DeviceCache.getDevice(this.device);
		basicMediaDevice.volumeUp(1);
		response.addInfo("Volume increased by 1 unit", true);
		setDeviceStatus(response, basicMediaDevice);
	}
	
	public void onVolumeDown(ViewRequest request, ViewResponse response) {
		BasicMediaDevice basicMediaDevice = (BasicMediaDevice) DeviceCache.getDevice(this.device);
		basicMediaDevice.volumeDown(1);
		response.addInfo("Volume decreased by 1 unit", true);
		setDeviceStatus(response, basicMediaDevice);
	}
	
}
