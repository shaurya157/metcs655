package edu.bu.met.cs665.view;

/**
 *  Class representing each available View Actions  
 */
public enum ViewAction {
	
	//select device action
	SELECT_TV("TV"),
	SELECT_RADIO("Radio"),
	SELECT_AC("AC"),
	DISCONNECT("Disconnect"),
	EXIT("Exit Controller"),
	//Control device action
	SWITCH_ON("Switch On"),
	SWITCH_OFF("Switch Off"),
	
	PLAY("Play"),
	PAUSE("Pause"),
	STOP("Stop"),
	
	VOLUME_UP("Volume Up"),
	VOLUME_DOWN("Volume Down"),
	
	TEMPARATURE_INCREASE("Temparature Up"),
	TEMPARATURE_DECREASE("Temparature Down"),
	
	FREQUENCEY_UP("Frequency Up"),
	FREQUENCEY_DOWN("Frequency Down"),
	
	
	RESET("Reset")
	
	;
	
	private String code;

	ViewAction(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return this.code;
	}
}
