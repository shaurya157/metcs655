package edu.bu.met.cs665.controller;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import edu.bu.met.cs665.device.Device;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * Abstract controller holds some basic device control operations,
 * which should be available for all devices. </br>
 * Some basic controls are Switch On, Switch Off, Disconnect, Exit.
 * 
 * processRequest method is implemented here.
 * The class extending this only need to write respective operation
 *  methods and add them to method map with respect to the action. Mandatory to implement loadMethodMap
 */
public abstract class AbstractDeviceController implements IController {

	Logger log = Logger.getLogger(AbstractDeviceController.class);
	public AbstractDeviceController() {
		this.init();
	}
	Map<ViewAction, String> methodMap = new HashMap<ViewAction, String>();
	/**
	 * Responsible for loading the methods with respect to action. </br>
	 * Example : </br>
	 * public void loadMethodMap() { </br> 
	 * 		&nbsp;&nbsp;methodMap.put(ViewAction.SWITCH_OFF, "onSwitchOff");// onSwitchOff is method name</br>
	 * } </br>
	 * No need to add methods of AbstractDeviceController<.br>
	 */
	abstract protected void loadMethodMap();
	
	public void init() {
		loadMethodMap();
		initBasicMethods();
	}
	
	private void initBasicMethods() {
		methodMap.put(ViewAction.SWITCH_OFF, "onSwitchOff");
		methodMap.put(ViewAction.SWITCH_ON, "onSwitchOn");
		methodMap.put(ViewAction.DISCONNECT, "onDisconnect");
		methodMap.put(ViewAction.EXIT, "onExit");
	}
	
	@Override
	public void processRequest(ViewRequest request, ViewResponse response) {
		try {
			Method method = this.getClass()
					.getMethod(methodMap.get(request.getAction()), request.getClass(), response.getClass());
			
			method.invoke(this, request, response);
			
		} catch (Exception e) {
			response.addError("Error ! Wrong command Entered.. \nPlease choose one of the following options", true);
			return;
		}
	}
	
	public void onSwitchOn(ViewRequest request, ViewResponse response) {
		Device device = DeviceCache.getDevice(request.getDevice());
		device.switchOnDevice();
		response.setType(request.getDevice());
		response.addInfo(new StringBuilder()
				.append(request.getDevice()).append(" switched on").toString(), true);
		setDeviceStatus(response, device);
	}
	
	public void onSwitchOff(ViewRequest request, ViewResponse response) {
		Device device = DeviceCache.getDevice(request.getDevice());
		device.switchOffDevice();
		response.setType(request.getDevice());
		response.addInfo(new StringBuilder()
				.append(request.getDevice()).append(" switched off").toString(), true);
		setDeviceStatus(response, device);
	}
	
	public void onDisconnect(ViewRequest request, ViewResponse response) {
		response.initView();
	}
	
	public void onExit(ViewRequest request, ViewResponse response) {
		log.info("@Exit command recieved..@");
		log.info("Stoping the application");
		System.exit(0);
	}
	

	protected void setDeviceStatus(ViewResponse response, Device device) {
		response.addInfo(device.getStatus(), false);
		response.setActions(device.getAvailableActions());
	}
}
