package edu.bu.met.cs665.device;

import java.util.Arrays;
import java.util.List;

import edu.bu.met.cs665.view.ViewAction;

/**
 * AbstractDevice responsible for switch on and of the any device.  
 *
 */
public  abstract class AbstractDevice implements Device {
	
	private DeviceStatus deviceStatus = DeviceStatus.OFF;

	abstract protected void resetDevice();
	@Override
	public DeviceStatus getDeviceStatus() {
		return deviceStatus;
	}

	public void setDeviceStatus(DeviceStatus status) {
		this.deviceStatus = status;
	}

	@Override
	public void switchOnDevice() {
		resetDevice();
		this.setDeviceStatus(DeviceStatus.ON);
	}

	@Override
	public void switchOffDevice() {
		this.setDeviceStatus(DeviceStatus.OFF);
	}
	
	protected List<ViewAction> getBasicControlls() {
		return Arrays.asList(ViewAction.SWITCH_OFF, ViewAction.DISCONNECT, ViewAction.EXIT);
	}
	
}
