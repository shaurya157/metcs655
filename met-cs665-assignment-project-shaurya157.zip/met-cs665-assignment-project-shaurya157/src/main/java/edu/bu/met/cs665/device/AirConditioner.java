package edu.bu.met.cs665.device;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.bu.met.cs665.device.controls.TemparatureEnabled;
import edu.bu.met.cs665.view.ViewAction;

/**
 * Air Conditioner device, emulation of real world AC, and will be responsible to implement {@link TemparatureEnabled} API's
 */
public class AirConditioner extends AbstractDevice implements TemparatureEnabled {
	
	public static final int ROOM_TEMP = 27;
	public static final int MAX = 40;
	public static final int MIN = 15;
	private double temparature = ROOM_TEMP;
	
	@Override
	public double getTemp() {
		return this.temparature;
	}

	@Override
	public void incrementTemp(double value) {
		this.temparature += value;
		if(this.temparature > MAX) this.temparature = MAX;
	}

	@Override
	public void decrementTemp(double value) {
		this.temparature -= value;
		if(this.temparature < MIN) this.temparature = MIN;
	}

	@Override
	public void reset() {
		this.temparature = ROOM_TEMP;
	}
	
	@Override
	public List<ViewAction> getAvailableActions() {
		if(DeviceStatus.OFF.equals(this.getDeviceStatus())) {
			return Arrays.asList(ViewAction.SWITCH_ON,  ViewAction.DISCONNECT, ViewAction.EXIT);
		}
		List<ViewAction> actions = new ArrayList<>();
		actions.addAll(Arrays.asList(ViewAction.TEMPARATURE_DECREASE, ViewAction.TEMPARATURE_INCREASE));
		actions.addAll(getBasicControlls());
		return actions;
	}
	
	@Override
	public String getStatus() {
		if(DeviceStatus.OFF.equals(this.getDeviceStatus())) {
			return  "AC is switched off. Please switch on..!";
		}
		
		StringBuilder sb = new StringBuilder("Temparature is ").append(getTemp()).append("*C");
		if(getTemp() == MAX) {
			sb.append("\n Maximum Temparature reached");
		}
		
		if(getTemp() == MIN) {
			sb.append("\n Minimun Temparature Reached");
		}
		return sb.toString();
	}

	@Override
	protected void resetDevice() {
		reset();
	}
}
