package edu.bu.met.cs665.device.controls;

public interface VolumeEnabled {

	int getVolume();
	
	//volumeUp
	void volumeUp(int value);
	
	//volumeDown
	void volumeDown(int value);
}
