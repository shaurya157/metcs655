package edu.bu.met.cs665.view;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.ViewLog.LogLevel;

/**
 * View Data is the structural representation of
 *  the data showed to user in the console.
 *  
 *  A singleton class, with a build which makes sure that only
 *   one ViewData object created in application life cycle
 */
public class ViewData {
	
	private DeviceType deviceType;
	private List<ViewAction> actions;
	private List<ViewLog> logs;
	private static ViewData instance = new ViewData(); // A singleton instance available everywhere
	
	private ViewData() {
		//do not allow to call this from out side.
	}
	
	public static ViewData getInstance() {
		return instance;
	}
	
	public DeviceType getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(DeviceType deviceType) {
		this.deviceType = deviceType;
	}
	
	public List<ViewAction> getActions() {
		return actions;
	}
	
	public void setActions(List<ViewAction> actions) {
		this.actions = actions;
	}
	
	public List<ViewLog> getLogs() {
		return logs;
	}
	
	public void setLogs(List<ViewLog> logs) {
		this.logs = logs;
	}
	
	public void show() {
		View.getInstance().write(this.toString());
	}
	
	public void resetLogs() {
		setLogs(new ArrayList<ViewLog>());
	}
	
	public void resetActions() {
		setActions(new ArrayList<ViewAction>());
	}
	
	@Override
	public String toString() {
		String logs = getLogs().stream().map(ViewLog::getMessage)
				.collect(Collectors.joining("\n"));
		
		String actions = IntStream.range(0, getActions().size())
				.mapToObj(i -> getAction(i))
				.collect(Collectors.joining(""));

		StringBuilder sb = new StringBuilder();
		sb.append("-------"); 
		if(this.getDeviceType().equals(DeviceType.CONNECTOR)) {
			sb.append("\n"); 
		} else {
			sb.append("Connected to ").append(this.getDeviceType().toString()).append(" \n"); 
		}
		sb.append(logs);
		sb.append("\n");
		sb.append(actions);
		sb.append("\nSelect options from 1-").append(getActions().size()).append(" :");
		return sb.toString();
	}

	private String getAction(int i) {
		StringBuilder button = new StringBuilder().append("(").append(i+1).append(") ")
				.append(getActions().get(i).getCode()).append(".   ");
		return button.toString();
	}
	
	/**
	 * 
	 * View Data Builder for update view data
	 *
	 */
	public static class ViewDataBuilder {
		private ViewData instance = ViewData.getInstance();
		
		public ViewDataBuilder deviceType(DeviceType type) {
			instance.setDeviceType(type);
			return this;
		}
		
		public ViewDataBuilder addAction(ViewAction action, boolean reset) {
			if(reset) {
				instance.setActions(new ArrayList<ViewAction>());
			}
			instance.getActions().add(action);
			return this;
		}
		
		private ViewDataBuilder addLog(ViewLog log, boolean reset) {
			if(reset) {
				instance.setLogs(new ArrayList<ViewLog>());
			}
			instance.getLogs().add(log);
			return this;
		}
		
		public ViewDataBuilder addInfo(String message, boolean reset) {
			return addLog(new ViewLog(message, LogLevel.INFO), reset);
		}
		
		public ViewData build() {
			return instance;
		}
	}
	

	public static ViewData initView(boolean isDisconnect) {
		ViewDataBuilder vb = new ViewDataBuilder()
			.deviceType(DeviceType.CONNECTOR)
			.addAction(ViewAction.SELECT_AC, true)
			.addAction(ViewAction.SELECT_TV, false)
			.addAction(ViewAction.SELECT_RADIO, false)
			.addAction(ViewAction.EXIT, false);
		
		if(isDisconnect) {
			vb.addInfo("Successfully Disconnected", true);
		} else {
			vb.addInfo(" ", true);
		}
		return vb
			.addInfo("@@ Welcome to Universal Device Controller @@", false)
			.addInfo("@@ Controll all your devices from one place @@", false)
			.addInfo("@@ Please Select the device to controll @@", false)
			.build();
		
	}
}
