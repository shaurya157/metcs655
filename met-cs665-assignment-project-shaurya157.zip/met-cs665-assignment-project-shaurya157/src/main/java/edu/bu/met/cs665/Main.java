package edu.bu.met.cs665;

import org.apache.log4j.Logger;

import edu.bu.met.cs665.application.ApplicationContext;

public class Main {

	private static Logger log = Logger.getLogger(Main.class);


	/**
	 * A main method to run examples.
	 *
	 * @param args not used
	 */
	public static void main(String[] args) {
		log.info("@@ Starting the Device Controller... @@");
		ApplicationContext.initContext();
	}
}
