package edu.bu.met.cs665.view;

public class ViewLog {

	private LogLevel level;
	private String message;
	
	public ViewLog(String message, LogLevel level) {
		this.level = level;
		this.message = message;
	}

	public LogLevel getLevel() {
		return level;
	}

	public void setLevel(LogLevel level) {
		this.level = level;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public static enum LogLevel {
		INFO,WARNING,ERROR
	}
}
