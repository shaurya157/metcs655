package edu.bu.met.cs665.device;

import edu.bu.met.cs665.device.controls.Playable;
import edu.bu.met.cs665.device.controls.VolumeEnabled;

/**
 * Basic Media device is implementing all basic media operations like Play, Stop, Increase Volume, etc.
 *
 */
public abstract class BasicMediaDevice extends AbstractDevice implements Playable, VolumeEnabled {

	private int volume = 5;
	private PlayStatus playStatus = PlayStatus.IDLE;
	protected static final int maxVolume = 20;

	@Override
	public int getVolume() {
		return volume;
	}

	@Override
	public void volumeUp(int value) {
		this.volume += value; 
		if(this.volume > maxVolume) this.volume = maxVolume;
	}

	@Override
	public void volumeDown(int value) {
		this.volume -= value;
		if(this.volume < 0) this.volume = 0;
	}

	@Override
	public PlayStatus getPlayStatus() {
		return playStatus;
	}

	@Override
	public void pause() {
		this.playStatus = PlayStatus.PAUSED;
	}

	@Override
	public void play() {
		this.playStatus = PlayStatus.PLAYING;
	}

	@Override
	public void stopPlay() {
		this.playStatus = PlayStatus.IDLE;
	}
	
	@Override
	protected void resetDevice() {
		this.stopPlay();
		this.volume=5;
	}
}
