package edu.bu.met.cs665.device;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.bu.met.cs665.view.ViewAction;

public class TeleVision extends BasicMediaDevice {

	@Override
	public List<ViewAction> getAvailableActions() {
		if(DeviceStatus.OFF.equals(this.getDeviceStatus())) {
			return Arrays.asList(ViewAction.SWITCH_ON, ViewAction.DISCONNECT, ViewAction.EXIT);
		}
		List<ViewAction> actions = new ArrayList<>();
		if(PlayStatus.IDLE.equals(this.getPlayStatus()) || PlayStatus.PAUSED.equals(this.getPlayStatus())) {
			actions.add(ViewAction.PLAY);
		} else  {
			actions.addAll(Arrays.asList(ViewAction.PAUSE,ViewAction.STOP, ViewAction.VOLUME_UP, ViewAction.VOLUME_DOWN));
		}
		actions.addAll(getBasicControlls());
		return actions;
	}

	@Override
	public String getStatus() {
		if(DeviceStatus.OFF.equals(this.getDeviceStatus())) {
			return  "Please switch on to play";
		}
		
		if(PlayStatus.IDLE.equals(this.getPlayStatus()) || PlayStatus.PAUSED.equals(this.getPlayStatus())) {
			return "Please click on play to continue";
		}
		
		StringBuilder status = new StringBuilder("TV is Playing.. \n Volume : ").append(getVolume());
		
		if(getVolume() == maxVolume) status.append("\n Maximum Volume Reached");
		
		return status.toString();
	}
}
