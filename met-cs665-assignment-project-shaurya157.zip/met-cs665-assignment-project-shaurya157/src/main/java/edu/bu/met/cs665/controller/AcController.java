package edu.bu.met.cs665.controller;

import edu.bu.met.cs665.device.AirConditioner;
import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * Controller for controlling AC device. 
 */
public class AcController extends AbstractDeviceController {
	public  AcController() {
		super();
	}
	@Override
	protected void loadMethodMap() {
		methodMap.put(ViewAction.TEMPARATURE_INCREASE, "onUp");
		methodMap.put(ViewAction.TEMPARATURE_DECREASE, "onDown");
		
		methodMap.put(ViewAction.DISCONNECT, "onDisconnect");
	}
	
	public void onUp(ViewRequest request, ViewResponse response) {
		AirConditioner ac  = (AirConditioner) DeviceCache.getDevice(DeviceType.AC);
		ac.incrementTemp(1.0);
		response.addInfo("Temperature increased by 1 unit", true);
		setDeviceStatus(response, ac);
	}
	
	public void onDown(ViewRequest request, ViewResponse response) {
		AirConditioner ac  = (AirConditioner) DeviceCache.getDevice(DeviceType.AC);
		ac.decrementTemp(1.0);
		response.addInfo("Temperature decreased by 1 unit", true);
		setDeviceStatus(response, ac);
	}
}
