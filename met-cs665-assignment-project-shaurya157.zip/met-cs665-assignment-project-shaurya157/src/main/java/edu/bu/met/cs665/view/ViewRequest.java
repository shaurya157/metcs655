package edu.bu.met.cs665.view;

import edu.bu.met.cs665.device.Device.DeviceType;

public class ViewRequest {

	private DeviceType device;
	private ViewAction action;
	
	public DeviceType getDevice() {
		return device;
	}
	
	public void setDevice(DeviceType device) {
		this.device = device;
	}
	
	public ViewAction getAction() {
		return action;
	}
	
	public void setAction(ViewAction action) {
		this.action = action;
	}
	
	public static class ViewRequestBuilder {
		private ViewRequest request;
		
		public ViewRequestBuilder() {
			this.request = new ViewRequest();
		}
		
		public ViewRequestBuilder device(DeviceType device) {
			this.request.setDevice(device);
			return this;
		}
		
		public ViewRequestBuilder action(ViewAction action) {
			this.request.setAction(action);
			return this;
		}
		
		public ViewRequest build() {
			return this.request;
		}
	}
}
