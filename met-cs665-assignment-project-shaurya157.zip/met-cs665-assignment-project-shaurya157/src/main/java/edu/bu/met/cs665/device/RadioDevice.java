package edu.bu.met.cs665.device;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.bu.met.cs665.device.controls.Tunable;
import edu.bu.met.cs665.view.ViewAction;

public class RadioDevice extends BasicMediaDevice implements Tunable {

	private double frequency = MIN;
	public static final int PRECISION = 2;
	private static final int MIN = 30;
	private static final int MAX = 130;
	
	@Override
	public double getFrequency() {
		return this.frequency;
	}

	@Override
	public void rotateRight(double value) {
		this.frequency += value;
		if(this.frequency > MAX) this.frequency = MAX;
	}

	@Override
	public void rotateLeft(double value) {
		this.frequency -= value;
		if(this.frequency < MIN) this.frequency = MIN;
	}
	
	@Override
	public List<ViewAction> getAvailableActions() {
		if(DeviceStatus.OFF.equals(this.getDeviceStatus())) {
			return Arrays.asList(ViewAction.SWITCH_ON, ViewAction.DISCONNECT, ViewAction.EXIT);
		}
		List<ViewAction> actions = new ArrayList<>();
		if(PlayStatus.IDLE.equals(this.getPlayStatus()) || PlayStatus.PAUSED.equals(this.getPlayStatus())) {
			actions.add(ViewAction.PLAY);
		} else {
			actions.addAll(Arrays.asList(ViewAction.PAUSE, ViewAction.STOP, ViewAction.VOLUME_UP, ViewAction.VOLUME_DOWN,
					ViewAction.FREQUENCEY_UP, ViewAction.FREQUENCEY_DOWN));
		}
		actions.addAll(getBasicControlls());
		return actions;
	}
	
	@Override
	public String getStatus() {
		if(DeviceStatus.OFF.equals(this.getDeviceStatus())) {
			return  "Please switch on to play";
		}

		if(PlayStatus.IDLE.equals(this.getPlayStatus()) || PlayStatus.PAUSED.equals(this.getPlayStatus())) {
			return "Please click on play to continue";
		} 

		StringBuilder status = new StringBuilder("Radio is Playing.. \n Volume : ").append(getVolume())
				.append("\n Frequence : ").append(getFrequency()).append("MHz");
		
		if(getVolume() == maxVolume) status.append("\n Maximum Volume Reached");
		
		if(getFrequency() == MAX)  status.append("\n Maximum Frequency Reached");
		
		return status.toString();
	}
}
