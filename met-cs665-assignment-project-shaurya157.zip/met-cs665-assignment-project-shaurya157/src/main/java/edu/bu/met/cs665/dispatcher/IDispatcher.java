package edu.bu.met.cs665.dispatcher;

import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * Responsible for handling all requests from the user and propagate it to respective Controller.
 *
 */
public interface IDispatcher {

	void handleRequest(ViewRequest action, ViewResponse respons);
}
