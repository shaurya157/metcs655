package edu.bu.met.cs665.device.controls;

public interface Switchable {

	void switchOnDevice();
	
	void switchOffDevice();
	
	DeviceStatus getDeviceStatus();
	
	public static enum DeviceStatus {
		ON, OFF
	}
}
