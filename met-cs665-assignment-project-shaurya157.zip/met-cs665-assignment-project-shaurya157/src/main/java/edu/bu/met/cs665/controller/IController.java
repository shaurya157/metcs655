package edu.bu.met.cs665.controller;

import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewResponse;

/**
 * Interface should be implemented by each device controllers </br>
 * 
 * See {@link AbstractDeviceController}
 */
public interface IController {

	void processRequest(ViewRequest request, ViewResponse response);
}
