package edu.bu.met.cs665.device;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;

public class DeviceCacheTest {

	@Test
	public void testDeviceCache() {
		assertEquals(AirConditioner.class, DeviceCache.getDevice(DeviceType.AC).getClass());
		assertEquals(RadioDevice.class, DeviceCache.getDevice(DeviceType.RADIO).getClass());
		assertEquals(TeleVision.class, DeviceCache.getDevice(DeviceType.TV).getClass());
	}
	
	@Test
	public void testDeviceType() {
		assertEquals("TV", DeviceType.TV.toString());
	}
}
