package edu.bu.met.cs665.view;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.view.ViewLog.LogLevel;

public class ViewLogTest {

	@Test
	public void testViewLog() {
		ViewLog viewLog = new ViewLog("Message", LogLevel.INFO);
		assertEquals("Message", viewLog.getMessage());
		assertEquals(LogLevel.INFO, viewLog.getLevel());
		viewLog.setMessage("Message");
		viewLog.setLevel(LogLevel.ERROR);
		assertEquals("Message", viewLog.getMessage());
		assertEquals(LogLevel.ERROR, viewLog.getLevel());
	}
}
