package edu.bu.met.cs665.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.device.TeleVision;
import edu.bu.met.cs665.device.controls.Playable.PlayStatus;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewData.ViewDataBuilder;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;
import edu.bu.met.cs665.view.ViewResponse;

public class TVControllerTest {

	
	@Test
	public void testPlay() {
		IController controller = new TvController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.TV).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.PLAY)
				.device(DeviceType.TV)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.TV, response.getType());
		assertEquals(PlayStatus.PLAYING,((TeleVision) DeviceCache.getDevice(DeviceType.TV)).getPlayStatus());
	}

	@Test
	public void testPause() {
		IController controller = new TvController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.TV).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.PAUSE)
				.device(DeviceType.TV)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.TV, response.getType());
		assertEquals(PlayStatus.PAUSED,((TeleVision) DeviceCache.getDevice(DeviceType.TV)).getPlayStatus());
	}
	
	

	@Test
	public void testStop() {
		IController controller = new TvController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.TV).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.STOP)
				.device(DeviceType.TV)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.TV, response.getType());
		assertEquals(PlayStatus.IDLE,((TeleVision) DeviceCache.getDevice(DeviceType.TV)).getPlayStatus());
	}
	
	@Test
	public void testVolumeUp() {
		IController controller = new TvController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.TV).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.VOLUME_UP)
				.device(DeviceType.TV)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.TV, response.getType());
		assertEquals(Double.valueOf(6), Double.valueOf(((TeleVision) DeviceCache.getDevice(DeviceType.TV)).getVolume()));
	}
	
	@Test
	public void testVolumeDown() {
		IController controller = new TvController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.TV).build());

		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.VOLUME_DOWN)
				.device(DeviceType.TV)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.TV, response.getType());
		assertEquals(Double.valueOf(5), Double.valueOf(((TeleVision) DeviceCache.getDevice(DeviceType.TV)).getVolume()));
	}
}
