package edu.bu.met.cs665.view;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;

public class ViewTest {

	@Test
	public void writeTest() {
		View instance = View.getInstance();
		instance.write("Write dummy");
	}
	
	@Test
	public void handleRequestTest() {
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		View instance = View.getInstance();
		instance.handleRequest(1, response);
		assertEquals(DeviceType.AC, response.getType());
	}
	
	@Test
	public void handleWrongRequestTest() {
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		View instance = View.getInstance();
		instance.handleRequest(5, response);
		assertEquals(1, response.getView().getLogs().size());
		instance.exit();
	}
}
