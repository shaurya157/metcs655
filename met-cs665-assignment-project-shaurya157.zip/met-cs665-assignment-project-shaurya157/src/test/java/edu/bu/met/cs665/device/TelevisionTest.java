package edu.bu.met.cs665.device;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.junit.Test;

import edu.bu.met.cs665.device.controls.Playable.PlayStatus;
import edu.bu.met.cs665.device.controls.Switchable.DeviceStatus;

public class TelevisionTest {
	Logger log = Logger.getLogger(TelevisionTest.class);
	
	@Test
	public void testSwitchOn() {
		TeleVision tv = new TeleVision();
		assertEquals(DeviceStatus.OFF,tv.getDeviceStatus());
		tv.switchOnDevice();
		assertEquals(DeviceStatus.ON,tv.getDeviceStatus());
		tv.switchOffDevice();
		assertEquals(DeviceStatus.OFF,tv.getDeviceStatus());
	}
	
	@Test
	public void testPlayStatus() {
		TeleVision tv = new TeleVision();
		tv.switchOnDevice();
		assertEquals(PlayStatus.IDLE, tv.getPlayStatus());
		tv.play();
		assertEquals(PlayStatus.PLAYING, tv.getPlayStatus());
		tv.pause();
		assertEquals(PlayStatus.PAUSED, tv.getPlayStatus());
		tv.stopPlay();
		assertEquals(PlayStatus.IDLE, tv.getPlayStatus());
	}
	
	@Test
	public void testVolume() {
		TeleVision tv = new TeleVision();
		tv.switchOnDevice();
		assertEquals(5, tv.getVolume());
		tv.volumeUp(5);
		assertEquals(10, tv.getVolume());
		tv.volumeUp(30);
		assertEquals(20, tv.getVolume());
		tv.volumeDown(5);
		assertEquals(15, tv.getVolume());
		tv.volumeDown(30);
		assertEquals(0, tv.getVolume());
	}
	
	@Test
	public void testReset() {
		TeleVision tv = new TeleVision();
		assertEquals(DeviceStatus.OFF,tv.getDeviceStatus());
		assertEquals(PlayStatus.IDLE, tv.getPlayStatus());
		tv.switchOnDevice();
		tv.play();
		assertEquals(PlayStatus.PLAYING, tv.getPlayStatus());
		tv.volumeUp(5);
		assertEquals(10, tv.getVolume());
		tv.resetDevice();
		assertEquals(PlayStatus.IDLE, tv.getPlayStatus());
		assertEquals(5, tv.getVolume());
	}
	
	@Test
	public void testAvailableActions() {
		TeleVision device = new TeleVision();
		assertEquals(3, device.getAvailableActions().size());
		device.switchOnDevice();
		assertEquals(4, device.getAvailableActions().size());
		device.pause();
		assertEquals(4, device.getAvailableActions().size());
		device.play();
		assertEquals(7, device.getAvailableActions().size());
	}
	
	@Test
	public void testStatus() {
		TeleVision device = new TeleVision();
		log.info(device.getStatus());
		device.switchOnDevice();
		device.pause();
		log.info(device.getStatus());
		device.play();
		log.info(device.getStatus());
		log.info(device.getStatus());
		device.volumeUp(20);
		log.info(device.getStatus());
	}
}
