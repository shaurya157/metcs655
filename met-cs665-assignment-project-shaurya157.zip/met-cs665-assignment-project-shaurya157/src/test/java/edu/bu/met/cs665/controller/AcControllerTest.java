package edu.bu.met.cs665.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.AirConditioner;
import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.device.controls.Switchable.DeviceStatus;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewData.ViewDataBuilder;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;
import edu.bu.met.cs665.view.ViewResponse;

public class AcControllerTest {

	@Test
	public void testeSwitchOn() {
		IController controller = new AcController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.AC).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.SWITCH_ON)
				.device(DeviceType.AC)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
		assertEquals(DeviceStatus.ON, DeviceCache.getDevice(DeviceType.AC).getDeviceStatus());
	}
	
	@Test
	public void testeSwitchOf() {
		IController controller = new AcController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.AC).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.SWITCH_ON)
				.device(DeviceType.AC)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
		assertEquals(DeviceStatus.ON, DeviceCache.getDevice(DeviceType.AC).getDeviceStatus());
		request =new ViewRequestBuilder()
				.action(ViewAction.SWITCH_OFF)
				.device(DeviceType.AC)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
		assertEquals(DeviceStatus.OFF, DeviceCache.getDevice(DeviceType.AC).getDeviceStatus());
	}
	

	@Test
	public void testDisconnect() {
		IController controller = new AcController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.AC).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.DISCONNECT)
				.device(DeviceType.AC)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.CONNECTOR, response.getType());
	}
	@Test
	public void testTempUp() {
		IController controller = new AcController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.AC).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.TEMPARATURE_INCREASE)
				.device(DeviceType.AC)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
		assertEquals(Double.valueOf(28), Double.valueOf(((AirConditioner) DeviceCache.getDevice(DeviceType.AC)).getTemp()));
	}
	
	@Test
	public void testTempDown() {
		IController controller = new AcController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.AC).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.TEMPARATURE_DECREASE)
				.device(DeviceType.AC)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
		assertEquals(Double.valueOf(26), Double.valueOf(((AirConditioner) DeviceCache.getDevice(DeviceType.AC)).getTemp()));
	}
}
