package edu.bu.met.cs665.dispatcher;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewData;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;
import edu.bu.met.cs665.view.ViewResponse;

public class IODispatcherTest {

	@Test
	public void ioDispatcherTest() {
		IDispatcher dispatcher = new IODispatcher();
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.SELECT_AC)
				.device(DeviceType.CONNECTOR)
				.build();
		dispatcher.handleRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
	}
}
