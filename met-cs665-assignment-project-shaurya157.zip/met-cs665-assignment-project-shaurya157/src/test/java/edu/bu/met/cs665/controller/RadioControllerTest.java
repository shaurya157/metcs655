package edu.bu.met.cs665.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.device.DeviceCache;
import edu.bu.met.cs665.device.RadioDevice;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewData.ViewDataBuilder;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;
import edu.bu.met.cs665.view.ViewResponse;

public class RadioControllerTest {


	@Test
	public void testFrequencyUp() {
		IController controller = new RadioController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.RADIO).build());
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.FREQUENCEY_UP)
				.device(DeviceType.RADIO)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.RADIO, response.getType());
		assertEquals(Double.valueOf(31), Double.valueOf(((RadioDevice) DeviceCache.getDevice(DeviceType.RADIO)).getFrequency()));
	}
	
	@Test
	public void testVolumeDown() {
		IController controller = new RadioController();
		ViewResponse response = new ViewResponse(new ViewDataBuilder()
				.deviceType(DeviceType.RADIO).build());

		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.FREQUENCEY_DOWN)
				.device(DeviceType.RADIO)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.RADIO, response.getType());
		assertEquals(Double.valueOf(30), Double.valueOf(((RadioDevice) DeviceCache.getDevice(DeviceType.RADIO)).getFrequency()));
	}
}
