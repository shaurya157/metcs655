package edu.bu.met.cs665.view;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.junit.Test;

public class ViewDataTest {

	Logger log = Logger.getLogger(ViewDataTest.class);

	@Test
	public void testViewData() {
		ViewData data = ViewData.initView(false);
		log.info(data.toString());
	}
	
	@Test
	public void testViewDataMethods() {
		ViewData data = ViewData.initView(true);
		data.resetActions();
		data.resetLogs();
		assertEquals(0, data.getActions().size());
		assertEquals(0, data.getLogs().size());
		data.show();
	}
}
