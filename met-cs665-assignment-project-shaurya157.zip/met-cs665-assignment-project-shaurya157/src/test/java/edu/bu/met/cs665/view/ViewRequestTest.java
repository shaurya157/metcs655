package edu.bu.met.cs665.view;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;

public class ViewRequestTest {

	@Test
	public void testViewRequest() {
		ViewRequest viewRequest = new ViewRequestBuilder()
				.device(DeviceType.AC)
				.action(ViewAction.DISCONNECT)
				.build();
		
		assertEquals(DeviceType.AC, viewRequest.getDevice());
		assertEquals(ViewAction.DISCONNECT, viewRequest.getAction());
	}
}
