package edu.bu.met.cs665.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;
import edu.bu.met.cs665.view.ViewAction;
import edu.bu.met.cs665.view.ViewData;
import edu.bu.met.cs665.view.ViewRequest;
import edu.bu.met.cs665.view.ViewRequest.ViewRequestBuilder;
import edu.bu.met.cs665.view.ViewResponse;

public class HomeControllerTest {


	@Test
	public void testonSelectAc() {
		IController controller = new HomeController();
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.SELECT_AC)
				.device(DeviceType.CONNECTOR)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.AC, response.getType());
	}
	
	@Test
	public void testOnSelectRadio() {
		IController controller = new HomeController();
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.SELECT_RADIO)
				.device(DeviceType.CONNECTOR)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.RADIO, response.getType());
	}
	
	@Test
	public void testOnSelectTv() {
		IController controller = new HomeController();
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.SELECT_TV)
				.device(DeviceType.CONNECTOR)
				.build();
		controller.processRequest(request, response);
		assertEquals(DeviceType.TV, response.getType());
	}
	
	@Test
	public void testOnSelectwrong() {
		IController controller = new HomeController();
		ViewResponse response = new ViewResponse(ViewData.initView(false));
		ViewRequest request =new ViewRequestBuilder()
				.action(ViewAction.VOLUME_DOWN)
				.device(DeviceType.CONNECTOR)
				.build();
		controller.processRequest(request, response);
		assertEquals(1,  response.getView().getLogs().size());
	}
}
