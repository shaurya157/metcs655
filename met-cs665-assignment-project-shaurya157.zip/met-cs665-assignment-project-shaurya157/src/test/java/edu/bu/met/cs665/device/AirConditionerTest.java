package edu.bu.met.cs665.device;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.junit.Test;

public class AirConditionerTest {

	Logger log = Logger.getLogger(AirConditionerTest.class);
	@Test
	public void testIncrementTemp() {
		AirConditioner ac = new AirConditioner();
		ac.incrementTemp(2);
		assertEquals(Double.valueOf(29), Double.valueOf(ac.getTemp()));
	}
	
	@Test
	public void testDecrementTemp() {
		AirConditioner ac = new AirConditioner();
		ac.decrementTemp(2);
		assertEquals(Double.valueOf(25), Double.valueOf(ac.getTemp()));
	}
	
	@Test
	public void testReset() {
		AirConditioner ac = new AirConditioner();
		ac.decrementTemp(2);
		assertEquals(Double.valueOf(25), Double.valueOf(ac.getTemp()));
		ac.reset();
		assertEquals(Double.valueOf(27), Double.valueOf(ac.getTemp()));
	}
	
	@Test
	public void testAvailableActions() {
		AirConditioner ac = new AirConditioner();
		assertEquals(3, ac.getAvailableActions().size());
		ac.switchOnDevice();
		assertEquals(5, ac.getAvailableActions().size());
	}
	
	@Test
	public void testStatus() {
		AirConditioner ac = new AirConditioner();
		log.info(ac.getStatus());
		ac.switchOnDevice();
		ac.incrementTemp(15);
		log.info(ac.getStatus());
		ac.decrementTemp(30);
		log.info(ac.getStatus());
	}
}
