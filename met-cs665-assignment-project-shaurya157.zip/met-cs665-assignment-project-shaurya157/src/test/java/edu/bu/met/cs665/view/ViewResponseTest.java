package edu.bu.met.cs665.view;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

import edu.bu.met.cs665.device.Device.DeviceType;

public class ViewResponseTest {

	@Test
	public void testViewResponse() {
		ViewResponse response = new ViewResponse(ViewData.getInstance());
		response.show();
		response.setType(DeviceType.AC);
		assertEquals(DeviceType.AC, response.getType());;
	}
	
	@Test
	public void testAddAction() {
		ViewResponse response = new ViewResponse(ViewData.getInstance());
		response.initView();
		response.addAction(ViewAction.DISCONNECT, true);
		assertEquals(1, response.getView().getActions().size());
		response.addAction(ViewAction.EXIT, false);
		assertEquals(2, response.getView().getActions().size());
		response.setActions(Arrays.asList(ViewAction.EXIT));
		assertEquals(1, response.getView().getActions().size());
	}
	@Test
	public void testAddLog() {
		ViewResponse response = new ViewResponse(ViewData.getInstance());
		response.addInfo("Message", true);
		assertEquals(1, response.getView().getLogs().size());
		response.addError("Message", false);
		assertEquals(2, response.getView().getLogs().size());
	}
}
