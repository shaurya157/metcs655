package edu.bu.met.cs665.device;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.junit.Test;

public class RadioDeviceTest {
	Logger log = Logger.getLogger(RadioDeviceTest.class);

	@Test
	public void fequencyTest() {
		RadioDevice device = new RadioDevice();
		assertEquals(Double.valueOf(30), Double.valueOf(device.getFrequency()));
	}
	
	@Test
	public void rotateRightTest() {
		RadioDevice device = new RadioDevice();
		device.rotateRight(2);
		assertEquals(Double.valueOf(32), Double.valueOf(device.getFrequency()));
		device.rotateRight(200);
		assertEquals(Double.valueOf(130), Double.valueOf(device.getFrequency()));
	}
	
	@Test
	public void rotateLeftTest() {
		RadioDevice device = new RadioDevice();
		device.rotateLeft(2);
		assertEquals(Double.valueOf(30), Double.valueOf(device.getFrequency()));
		device.rotateRight(200);
		assertEquals(Double.valueOf(130), Double.valueOf(device.getFrequency()));
		device.rotateLeft(30);
		assertEquals(Double.valueOf(100), Double.valueOf(device.getFrequency()));
	}
	
	@Test
	public void testAvailableActions() {
		RadioDevice device = new RadioDevice();
		assertEquals(3, device.getAvailableActions().size());
		device.switchOnDevice();
		assertEquals(4, device.getAvailableActions().size());
		device.pause();
		assertEquals(4, device.getAvailableActions().size());
		device.play();
		assertEquals(9, device.getAvailableActions().size());
	}
	
	@Test
	public void testStatus() {
		RadioDevice device = new RadioDevice();
		log.info(device.getStatus());
		device.switchOnDevice();
		device.pause();
		log.info(device.getStatus());
		device.play();
		log.info(device.getStatus());
		device.rotateRight(200);
		log.info(device.getStatus());
		device.volumeUp(20);
		log.info(device.getStatus());
	}
}
