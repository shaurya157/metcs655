#!/bin/bash
mvn clean compile assembly:single
java -jar target/assignment-project-1.0-SNAPSHOT-jar-with-dependencies.jar