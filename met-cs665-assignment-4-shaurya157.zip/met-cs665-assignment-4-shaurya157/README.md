# CS665 Assignment 4

This is assignment 4 for CS665.  The following readme can be used as user guide
to install and run the application using Java.  


# Program Assumptions

This is a example for migrating the application from using a old API to use new API. 

In this application, I assumed that a legacy service was built to use a API from legacy USB Data source. And when a new Rest Data source API is introduced, the service has to be changed to use new data source. And it has to be done step by step, as a first step the service has to use the old API  but should access data from new system .

The application can be easily configurable to use any type of the data sources. 

The behaviour of  application is tested with JUnit test cases. 

# Implementation Description

This example uses a simple implementation of **Adapter Design Pattern**, to migrate the usage of the data source from USB to REST. Where the system still uses the API from USB interface. And an implementation of the USB interface is an adapter to connect to a REST interface. This implementation can be injected easily to service class using **Dependency Injection Pattern**.  

Using this dependency injection we can configure the application to use particular data source.


UML class diagram for implementation is assignment-4-uml.pdf

# Project Template

We use Apache Maven and JDK1.8 to compile and run this project. 

Please make sure that `java` and `mvn` commands are added to system path. 


# How to compile the project

```bash
mvn clean compile
```

# How to create a binary runnable package 


```bash
mvn clean compile assembly:single
```


# How to run


```bash
mvn clean compile assembly:single

java -jar ./target/assignment-4-1.0-SNAPSHOT-jar-with-dependencies.jar

OR

./run.sh
```


# Run all the unit test classes.


```bash
mvn clean compile test

```

# Using Findbugs 

To see bug detail using the Findbugs GUI, use the following command "mvn findbugs:gui"

Or you can create a XML report by using  


```bash
mvn findbugs:gui 
```

or 


```bash
mvn findbugs:findbugs
```


For more info about FindBugs see 

http://findbugs.sourceforge.net/

And about Maven Findbug plugin see 
https://gleclaire.github.io/findbugs-maven-plugin/index.html


You can install Findbugs Eclipse Plugin 

http://findbugs.sourceforge.net/manual/eclipse.html



SpotBugs https://spotbugs.github.io/ is the spiritual successor of FindBugs.


# Run Checkstyle 

CheckStyle code styling configuration files are in config/ directory. Maven checkstyle plugin is set to use google code style. 
You can change it to other styles like sun checkstyle. 

To analyze this example using CheckStyle run 

```bash
mvn checkstyle:check
```

This will generate a report in XML format


```bash
target/checkstyle-checker.xml
target/checkstyle-result.xml
```

and the following command will generate a report in HTML format that you can open it using a Web browser. 

```bash
mvn checkstyle:checkstyle
```

```bash
target/site/checkstyle.html
```


# Generate  coveralls:report 

You can find more info about coveralls 

https://coveralls.io/

```bash
mvn -DrepoToken=YOUR-REPO-TOCKEN-ON-COVERALLS  cobertura:cobertura coveralls:report
```


