package edu.bu.met.cs665.usb;

import org.junit.Test;

public class ConcreteCustomerDataOverUsbTest {

	@Test
	public void testUsbDataSource() {
		ICustomerDataOverUsb usbDataSource = new ConcreteCustomerDataOverUSB();
		usbDataSource.printCustomerData(1);
		usbDataSource.getCustomerData_withUSBConnection(1);
		usbDataSource.printCustomerData(10);
	}
}
