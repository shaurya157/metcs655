package edu.bu.met.cs665.customer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.apache.log4j.Logger;
import org.junit.Test;

public class CustomerTest {

	Logger log = Logger.getLogger(CustomerTest.class);
	
	@Test
	public void testCustomer() {
		Customer customer = new Customer(1, "Cus1", "cus@email.com");
		assertEquals(1, customer.getId());
		assertEquals("Cus1", customer.getName());
		assertEquals("cus@email.com", customer.getEmail());
		log.info(customer.toString());
	}
	
	@Test
	public void testCustomerList() {
		assertNotNull(Customer.customers);
		assertEquals(4, Customer.customers.size());
	}
}
