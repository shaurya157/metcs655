package edu.bu.met.cs665.rest;

import org.junit.Test;

public class ConcreteCustomerDataOverRestTest {

	@Test
	public void testCustomerDataOverRest() {
		ICustomerDataOverRest restDataSource = new ConcreteCustomerDataOverRest();
		restDataSource.printCustomerData(2);
		restDataSource.getCustomerData_withHTTPConnection(2);
		restDataSource.printCustomerData(10);
	}
}
