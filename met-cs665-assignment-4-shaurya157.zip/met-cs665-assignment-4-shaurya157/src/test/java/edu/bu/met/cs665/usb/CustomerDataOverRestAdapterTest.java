package edu.bu.met.cs665.usb;

import org.junit.Test;

public class CustomerDataOverRestAdapterTest {

	@Test
	public void testRestAdapterDataSource() {
		ICustomerDataOverUsb usbDataSource = new CustomerDataOverRestAdapter();
		usbDataSource.printCustomerData(1);
		usbDataSource.getCustomerData_withUSBConnection(1);
	}
}
