package edu.bu.met.cs665.client;

import org.junit.Test;

import edu.bu.met.cs665.usb.ConcreteCustomerDataOverUSB;

public class CustomerDataServiceTest {

	@Test
	public void testCustomerDataServiceTest() {
		CustomerDataService service = new CustomerDataService();
		service.setCustomerDataSource(new ConcreteCustomerDataOverUSB());
		service.printCustomerData(2);
		service.printCustomerData(10);
	}
}
