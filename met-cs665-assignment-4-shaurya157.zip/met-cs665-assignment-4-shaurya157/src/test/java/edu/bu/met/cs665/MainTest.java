package edu.bu.met.cs665;

import org.junit.Test;

public class MainTest {

	@Test
	public void testMain() {
		Main.printCustomerData(1, "rest");
		Main.printCustomerData(2, "usb");
		Main.printCustomerData(2, null);
	}
}
