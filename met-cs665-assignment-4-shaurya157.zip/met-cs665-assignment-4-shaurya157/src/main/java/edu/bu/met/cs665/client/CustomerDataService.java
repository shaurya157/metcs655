package edu.bu.met.cs665.client;

import edu.bu.met.cs665.usb.ICustomerDataOverUsb;
/**
 * Legacy customer data service which is consuming data from a legacy USB data source.
 * 
 * We can inject a data source of type USB to this service through dependency injection. 
 *
 */
public class CustomerDataService {

	private ICustomerDataOverUsb customerDataSource;
	
	/**
	 * Setter to inject a data source dynamically to the service. 
	 * @param customerDataSource
	 */
	public void setCustomerDataSource(ICustomerDataOverUsb customerDataSource) {
		this.customerDataSource = customerDataSource;
	}
	
	public void printCustomerData(int id) {
		if(this.customerDataSource  != null) {
			this.customerDataSource.printCustomerData(id);
		}
	}
}
