package edu.bu.met.cs665;

import edu.bu.met.cs665.client.CustomerDataService;
import edu.bu.met.cs665.usb.ConcreteCustomerDataOverUSB;
import edu.bu.met.cs665.usb.CustomerDataOverRestAdapter;
import edu.bu.met.cs665.usb.ICustomerDataOverUsb;

public class Main {

  /**
   * A main method to run examples.
   *
   * @param args not used
   */
  public static void main(String[] args) {

	  printCustomerData(1, "rest");
	  printCustomerData(2, "rest");
	  printCustomerData(4, "rest");
	  printCustomerData(1, "rest");
	  printCustomerData(2, "usb");

  }
  
  private static CustomerDataService service = new CustomerDataService();
  private static ICustomerDataOverUsb usbDataSource = new ConcreteCustomerDataOverUSB();
  private static ICustomerDataOverUsb adapterForRest = new CustomerDataOverRestAdapter();
  
  public static void printCustomerData(int id, String dataSourceType) {
	  if("rest".equalsIgnoreCase(dataSourceType)) {
		  service.setCustomerDataSource(adapterForRest); //Inject Adapter
	  } else if ("usb".equalsIgnoreCase(dataSourceType)) {
		  service.setCustomerDataSource(usbDataSource); // Inject Legacy Usb data source
	  } else {
		  service.setCustomerDataSource(adapterForRest); //default data source
	  }
	  service.printCustomerData(id);
  }
}
