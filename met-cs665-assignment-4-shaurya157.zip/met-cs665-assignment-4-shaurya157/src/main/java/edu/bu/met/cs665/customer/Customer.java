package edu.bu.met.cs665.customer;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	
	private int id;
	private String name;
	private String email;
	
	public Customer(int id, String name, String email) {
		this.id = id;
		this.name = name;
		this.email = email;
	}
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public static List<Customer> customers = new ArrayList<Customer>();
	static {
		customers.add(new Customer(1, "Customer 1", "customer1@email.com"));
		customers.add(new Customer(2, "Customer 2", "customer2@email.com"));
		customers.add(new Customer(3, "Customer 3", "customer3@email.com"));
		customers.add(new Customer(4, "Customer 4", "customer4@email.com"));
	}
	
	@Override
	public String toString() {
		return new StringBuilder()
				.append("Customer ID:").append(getId())
				.append(", Name:").append(getName())
				.append(", Email:").append(getEmail()).toString();
	}
}
