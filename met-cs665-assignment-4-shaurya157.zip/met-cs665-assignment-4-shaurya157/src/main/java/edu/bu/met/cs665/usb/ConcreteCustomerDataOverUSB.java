package edu.bu.met.cs665.usb;

import java.util.Optional;

import org.apache.log4j.Logger;

import edu.bu.met.cs665.customer.Customer;

public class ConcreteCustomerDataOverUSB implements ICustomerDataOverUsb {

	Logger log = Logger.getLogger(ConcreteCustomerDataOverUSB.class);

	@Override
	public void printCustomerData(int customerId) {
		getCustomerData_withUSBConnection(customerId);
	}

	@Override
	public void getCustomerData_withUSBConnection(int customerId) {
		log.info("Collecting customer data from USB source. ");
		Optional<Customer> c = Customer.customers.stream().filter(i -> i.getId() == customerId)
				.findFirst();
		if(c.isPresent()) {
			log.info(c.get().toString());
		} else {
			log.info("No Customer found for id " + customerId);
		}
	}

}
