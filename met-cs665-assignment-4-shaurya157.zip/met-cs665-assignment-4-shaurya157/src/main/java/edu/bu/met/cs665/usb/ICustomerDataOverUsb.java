package edu.bu.met.cs665.usb;

public interface ICustomerDataOverUsb {

	/**
	 * Prints the customer data for given id.
	 * @param customerId
	 */
	void printCustomerData(int customerId);
	
	/**
	 * Collects the customer data from USB Source 
	 * @param customerId
	 */
	void getCustomerData_withUSBConnection(int customerId); 
}
