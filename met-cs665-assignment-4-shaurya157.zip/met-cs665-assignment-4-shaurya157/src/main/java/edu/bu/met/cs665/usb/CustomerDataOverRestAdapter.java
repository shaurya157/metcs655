package edu.bu.met.cs665.usb;

import edu.bu.met.cs665.rest.ConcreteCustomerDataOverRest;
import edu.bu.met.cs665.rest.ICustomerDataOverRest;

/**
 * An Adapter for REST Data source through USB Data source.  
 *
 */
public class CustomerDataOverRestAdapter implements ICustomerDataOverUsb {

	private ICustomerDataOverRest customerDataSourceRest = new ConcreteCustomerDataOverRest();

	public ICustomerDataOverRest getCustomerDataSourceRest() {
		return customerDataSourceRest;
	}

	public void setCustomerDataSourceRest(ICustomerDataOverRest customerDataSourceRest) {
		this.customerDataSourceRest = customerDataSourceRest;
	}

	@Override
	public void printCustomerData(int customerId) {
		getCustomerDataSourceRest().printCustomerData(customerId);
	}

	@Override
	public void getCustomerData_withUSBConnection(int customerId) {
		getCustomerDataSourceRest().getCustomerData_withHTTPConnection(customerId);
	}
	
	
}
