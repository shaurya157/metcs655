package edu.bu.met.cs665.rest;

import java.util.Optional;

import org.apache.log4j.Logger;

import edu.bu.met.cs665.customer.Customer;

/**
 * Concrete implementation of HTTP Data source. 
 *
 */
public class ConcreteCustomerDataOverRest implements ICustomerDataOverRest {

	Logger log = Logger.getLogger(ConcreteCustomerDataOverRest.class);
	
	@Override
	public void printCustomerData(int customerId) {
		getCustomerData_withHTTPConnection(customerId);
	}

	@Override
	public void getCustomerData_withHTTPConnection(int customerId) {
		log.info("Collecting customer data from REST source. ");
		Optional<Customer> c = Customer.customers.stream().filter(i -> i.getId() == customerId)
				.findFirst();
		if(c.isPresent()) {
			log.info(c.get().toString());
		} else {
			log.info("No Customer found for id " + customerId);
		}
	}

}
