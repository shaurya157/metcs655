package edu.bu.met.cs665.rest;

public interface ICustomerDataOverRest {

	/**
	 * Prints customer data for given id.
	 * @param customerId
	 */
	void printCustomerData(int customerId);
	
	/**
	 * Collects the  customer data for given id from HTTP source.
	 * @param customerId
	 */
	void getCustomerData_withHTTPConnection(int customerId); 
}
