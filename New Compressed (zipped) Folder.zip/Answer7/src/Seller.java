public class Seller {
    public String name;
    public Seller(String name){
        this.name = name;
    }
}
